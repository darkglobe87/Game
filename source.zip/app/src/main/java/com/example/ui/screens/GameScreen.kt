package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.isActive
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.KeyboardKey
import com.example.ui.components.LetterBox
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant

import com.example.ui.theme.NeonPurple
import com.example.viewmodel.GameStatus
import com.example.viewmodel.GameViewModel

data class Particle(
    var x: Float,
    var y: Float,
    var z: Float,
    var vx: Float,
    var vy: Float,
    var vz: Float,
    val color: Color
)

@Composable
fun ParticleBackground(particleCount: Int = 55) {
    val particles = androidx.compose.runtime.remember {
        List(particleCount) {
            Particle(
                x = kotlin.random.Random.nextFloat() * 2000f - 1000f,
                y = kotlin.random.Random.nextFloat() * 2000f - 1000f,
                z = kotlin.random.Random.nextFloat() * 1000f,
                vx = kotlin.random.Random.nextFloat() * 1f - 0.5f,
                vy = kotlin.random.Random.nextFloat() * 1f - 0.5f,
                vz = kotlin.random.Random.nextFloat() * -3f - 1f, // Gentler drift towards viewer
                color = listOf(NeonCyan, NeonPink, NeonPurple, Color.White).random()
            )
        }
    }

    var time by androidx.compose.runtime.remember { androidx.compose.runtime.mutableLongStateOf(0L) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        var lastTime = withFrameNanos { it }
        while (isActive) {
            withFrameNanos { frameTime ->
                val dt = (frameTime - lastTime) / 16_000_000f // normalized dt
                lastTime = frameTime
                time = frameTime

                for (p in particles) {
                    p.x += p.vx * dt
                    p.y += p.vy * dt
                    p.z += p.vz * dt

                    // Reset if out of bounds (moving past camera)
                    if (p.z < 10f) {
                        p.z = 1000f
                        p.x = kotlin.random.Random.nextFloat() * 2000f - 1000f
                        p.y = kotlin.random.Random.nextFloat() * 2000f - 1000f
                    }
                }
            }
        }
    }

    androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
        // Reading time here only invalidates the draw phase, not full recomposition
        time.let {}

        val width = size.width
        val height = size.height
        val centerX = width / 2f
        val centerY = height / 2f
        val fov = 400f

        for (p in particles) {
            val scale = fov / (fov + p.z)
            val projX = p.x * scale + centerX
            val projY = p.y * scale + centerY
            // Small and dim so it reads as ambient depth, not a foreground distraction
            val radius = (6f * scale).coerceIn(0.5f, 6f)
            val alpha = (1f - (p.z / 1000f)).coerceIn(0.05f, 0.4f)

            if (projX in -50f..width + 50f && projY in -50f..height + 50f) {
                drawCircle(
                    color = p.color.copy(alpha = alpha),
                    radius = radius,
                    center = androidx.compose.ui.geometry.Offset(projX, projY)
                )
            }
        }
    }
}

@Composable
fun HowToPlayDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("How to Play", color = NeonCyan) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("1. Read the hilariously bad description of a famous movie.")
                Text("2. Guess the letters to reveal the movie's title.")
                Text("3. Use your coins to buy hints if you get stuck.")
                Text("4. Guess correctly to earn more coins and progress to new movies!")
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Got it", color = NeonPink)
            }
        },
        containerColor = DarkSurface
    )
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    viewModel: GameViewModel,
    onNavigateToStore: () -> Unit,
    onNavigateHome: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val userState by viewModel.userState.collectAsState()
    var showHowToPlay by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val snackbarHostState = androidx.compose.runtime.remember { SnackbarHostState() }

    if (showHowToPlay) {
        HowToPlayDialog(onDismiss = { showHowToPlay = false })
    }

    androidx.compose.runtime.LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.consumeSnackbarMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("BAD PLOTS", fontWeight = FontWeight.Black, color = NeonCyan, letterSpacing = 2.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateHome) {
                        Icon(Icons.Default.Home, contentDescription = "Main Menu", tint = NeonCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                ),
                actions = {
                    IconButton(onClick = { showHowToPlay = true }) {
                        Icon(Icons.Default.Info, contentDescription = "How to Play", tint = NeonCyan)
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = "Coins", tint = Color(0xFFFFD700), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("${userState?.coins ?: 0}", fontWeight = FontWeight.Bold)
                        }
                    }
                    IconButton(onClick = onNavigateToStore) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Store", tint = NeonPink)
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize()) {
            ParticleBackground()
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
            if (uiState.isLoadingNewLevel) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = NeonCyan)
                        Spacer(Modifier.height(16.dp))
                        Text("Loading next movie...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                    }
                }
                return@Scaffold
            }
            
            if (uiState.error != null) {
                Text(uiState.error!!, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { viewModel.retryLevel() }, colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)) {
                    Text("Retry")
                }
                return@Scaffold
            }

            // Game Status Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Level ${ (userState?.currentLevelIndex ?: 0) + 1 }", color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Lives: ", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${uiState.lives}", color = if (uiState.lives > 3) NeonCyan else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Black, fontSize = 20.sp)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Bad Description Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        text = "\"${uiState.currentMovie?.badDescription}\"",
                        fontSize = 18.sp,
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 24.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Word Layout
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                uiState.currentMovie?.title?.split(" ")?.forEach { word ->
                    Row(
                        modifier = Modifier.padding(end = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        word.forEach { char ->
                            val isRevealed = char.uppercaseChar() in uiState.guessedLetters
                            LetterBox(
                                char = char,
                                isRevealed = isRevealed,
                                isSpace = false
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // End Game State
            if (uiState.status != GameStatus.Playing) {
                val won = uiState.status == GameStatus.Won
                val titleColor = if (won) NeonCyan else MaterialTheme.colorScheme.error
                
                val visibleState = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
                androidx.compose.runtime.LaunchedEffect(Unit) { visibleState.value = true }
                
                AnimatedVisibility(
                    visible = visibleState.value,
                    enter = scaleIn(tween(500, easing = FastOutSlowInEasing)) + fadeIn(tween(500))
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (won) "CORRECT!" else "GAME OVER",
                            color = titleColor,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black
                        )
                        if (!won) {
                            Text("It was: ${uiState.currentMovie?.title}", color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.nextLevel() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Text("NEXT LEVEL")
                }
                Spacer(modifier = Modifier.height(16.dp))
            } else {
                // Hint System
                val costLetter = if (userState?.hasPurchasedAdFree == true) 0 else 10
                val costClue = if (userState?.hasPurchasedAdFree == true) 0 else 15
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    HintButton(
                        icon = Icons.Default.Lightbulb,
                        label = "Letter",
                        cost = costLetter,
                        isRevealed = false,
                        onClick = { viewModel.useLetterHint() }
                    )
                    HintButton(
                        icon = Icons.Default.Person,
                        label = "Character",
                        cost = costClue,
                        isRevealed = uiState.revealedCharacterHint,
                        onClick = { viewModel.revealClue("character") }
                    )
                    HintButton(
                        icon = Icons.Default.Movie,
                        label = "Scene",
                        cost = costClue,
                        isRevealed = uiState.revealedSceneHint,
                        onClick = { viewModel.revealClue("scene") }
                    )
                }

                // Show active clues
                Column(modifier = Modifier.padding(top = 16.dp).fillMaxWidth()) {
                    if (uiState.revealedCharacterHint) {
                        ClueText("Character: ${uiState.currentMovie?.characterHint}")
                    }
                    if (uiState.revealedSceneHint) {
                        ClueText("Scene: ${uiState.currentMovie?.sceneHint}")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Keyboard
                val rows = listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rows.forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            row.forEach { letter ->
                                val isGuessed = letter in uiState.guessedLetters
                                val isCorrect = if (isGuessed) letter in (uiState.currentMovie?.title?.uppercase() ?: "") else null
                                KeyboardKey(
                                    letter = letter,
                                    isGuessed = isGuessed,
                                    isCorrect = isCorrect,
                                    onClick = { viewModel.guessLetter(letter) },
                                    modifier = Modifier.weight(1f, fill = false).widthIn(min = 32.dp)
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
        }
    }
}

@Composable
fun ClueText(text: String) {
    Text(
        text = text,
        color = NeonCyan,
        fontSize = 14.sp,
        modifier = Modifier.padding(vertical = 4.dp).background(NeonCyan.copy(alpha=0.1f), RoundedCornerShape(4.dp)).padding(8.dp).fillMaxWidth()
    )
}

@Composable
fun HintButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    cost: Int,
    isRevealed: Boolean,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(
            onClick = onClick,
            enabled = !isRevealed,
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = NeonPink
            ),
            modifier = Modifier.size(48.dp)
        ) {
            Icon(icon, contentDescription = label)
        }
        Spacer(Modifier.height(4.dp))
        if (!isRevealed) {
            if (cost == 0) {
                Text("FREE", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = "Coins", tint = Color(0xFFFFD700), modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(2.dp))
                    Text("$cost", color = MaterialTheme.colorScheme.onBackground, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Text("Revealed", color = NeonCyan, fontSize = 12.sp)
        }
    }
}
