package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.NeonCyan

@Composable
fun LetterBox(
    char: Char,
    isRevealed: Boolean,
    modifier: Modifier = Modifier,
    isSpace: Boolean = false
) {
    if (isSpace) {
        Box(modifier = modifier.size(40.dp))
        return
    }

    val backgroundColor = if (isRevealed) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent
    val borderColor = if (isRevealed) NeonCyan else MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (isRevealed) NeonCyan else Color.Transparent

    Box(
        modifier = modifier
            .size(40.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .border(2.dp, borderColor, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = char.uppercase(),
            color = textColor,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
