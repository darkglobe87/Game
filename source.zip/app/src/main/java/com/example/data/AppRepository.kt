package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.serialization.json.Json

class AppRepository(
    private val appDao: AppDao,
    private val context: Context
) {
    val allMovies: Flow<List<Movie>> = appDao.getAllMovies()
    val userState: Flow<UserState?> = appDao.getUserStateFlow()

    suspend fun initializePrepopulatedData() {
        val existingMovies = appDao.getAllMovies().firstOrNull()
        if (existingMovies.isNullOrEmpty()) {
            val initialMovies = try {
                val jsonString = context.assets.open("movies.json").bufferedReader().use { it.readText() }
                Json.decodeFromString<List<Movie>>(jsonString)
            } catch (e: Exception) {
                e.printStackTrace()
                emptyList()
            }
            if (initialMovies.isNotEmpty()) {
                appDao.insertMovies(initialMovies)
            }
        }
        
        val state = appDao.getUserState()
        if (state == null) {
            appDao.insertUserState(UserState(coins = 50, currentLevelIndex = 0))
        }
    }

    suspend fun insertMovie(movie: Movie): Long {
        return appDao.insertMovie(movie)
    }
    
    suspend fun spendCoins(amount: Int): Boolean {
        val state = appDao.getUserState() ?: return false
        if (state.coins >= amount) {
            appDao.updateUserState(state.copy(coins = state.coins - amount))
            return true
        }
        return false
    }

    suspend fun addCoins(amount: Int) {
        val state = appDao.getUserState()
        if (state != null) {
            appDao.updateUserState(state.copy(coins = state.coins + amount))
        }
    }

    suspend fun advanceLevel() {
        val state = appDao.getUserState()
        if (state != null) {
            appDao.updateUserState(state.copy(currentLevelIndex = state.currentLevelIndex + 1))
        }
    }
    
    suspend fun purchaseAdFree() {
        val state = appDao.getUserState()
        if (state != null) {
            appDao.updateUserState(state.copy(hasPurchasedAdFree = true))
        }
    }
}
