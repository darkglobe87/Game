DROP YOUR MUSIC FILE HERE.

1. Download a looping ambient track (CC0 / royalty-free) from:
   - https://pixabay.com/music/  (search "ethereal ambient")
   - https://freesound.org/  (filter License = CC0, search "ambient ethereal drone")

2. Rename it to exactly:  bg_music.mp3   (or bg_music.ogg)

3. Put it in this folder:  app/src/main/res/raw/

4. Delete this PLACEHOLDER_README.txt file (optional, but tidy).

RULES:
- Android resource filenames must be lowercase letters, digits, underscores only.
  "bg_music.mp3" is correct. "BG-Music.mp3" or "bg music.mp3" will FAIL the build.
- The app builds and runs fine WITHOUT this file - it just plays no music.
  The music turns on automatically the moment a file named bg_music.<ext> is present.
- The mute button (music note icon, top bar) works regardless.
